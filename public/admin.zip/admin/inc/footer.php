    <footer class="iq-footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6">
                    <ul class="list-inline mb-0">
                        <li class="list-inline-item"><a href="../backend/privacy-policy.html">Pol&iacute;ticas de privacidad</a></li>
                        <li class="list-inline-item"><a href="../backend/terms-of-service.html">T&eacute;rminos de uso</a></li>
                    </ul>
                </div>
                <div class="col-lg-6 text-right">
                    <span class="mr-1">
                        Copyright
                        <script>document.write(new Date().getFullYear())</script>© <a href="#" class="">platIA</a>
                        Todos los derechos reservados.
                    </span>
                </div>
            </div>
        </div>
    </footer>