<?php
// registrar.php - responde siempre JSON
header('Content-Type: application/json; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require '../config.php'; // debe definir $link (mysqli)

// Método POST requerido
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["status" => "error", "message" => "Método no permitido"]);
    exit;
}

// Recoger inputs (evitar NULL)
$nombre      = trim($_POST['nombre'] ?? '');
$apellido    = trim($_POST['apellido'] ?? '');
$correoUser  = trim($_POST['correo'] ?? '');

$empresa_nombre    = trim($_POST['empresa_nombre'] ?? '');
$empresa_email     = trim($_POST['empresa_email'] ?? '');
$empresa_direccion = trim($_POST['empresa_direccion'] ?? '');
$empresa_ruc       = trim($_POST['empresa_ruc'] ?? '');
$latitud           = trim($_POST['empresa_latitud'] ?? '');
$longitud          = trim($_POST['empresa_longitud'] ?? '');

// Validaciones básicas
if (!$nombre || !$apellido || !$correoUser) {
    echo json_encode(["status" => "error", "message" => "Completa los datos del usuario."]);
    exit;
}
if (!$empresa_nombre || $latitud === '' || $longitud === '') {
    echo json_encode(["status" => "error", "message" => "Faltan datos de la empresa."]);
    exit;
}

// Generar contraseña temporal (plana) y hash
$passPlano = "Usr" . date("Y") . "@" . rand(1000, 9999);
$passHash = password_hash($passPlano, PASSWORD_DEFAULT);

// ===== INSERT EMPRESA =====
// Nota: query tiene 6 placeholders: nombre, email_contacto, direccion, latitud, longitud, ruc
$sqlEmpresa = "INSERT INTO empresas 
  (nombre, email_contacto, idRubro, activa, creada_en, direccion, latitud, longitud, ruc, idUsuarioResponsable) 
  VALUES (?, ?, 3, 1, NOW(), ?, ?, ?, ?, 0)";

$stmt = $link->prepare($sqlEmpresa);
if (!$stmt) {
    echo json_encode(["status" => "error", "message" => "Error al preparar empresa: " . $link->error]);
    exit;
}

// Tipos: s (nombre), s (email), s (direccion), d (latitud), d (longitud), s (ruc)
$stmt->bind_param(
    "sssdds",
    $empresa_nombre,
    $empresa_email,
    $empresa_direccion,
    $latitud,
    $longitud,
    $empresa_ruc
);

if (!$stmt->execute()) {
    echo json_encode(["status" => "error", "message" => "Error al insertar empresa: " . $stmt->error]);
    $stmt->close();
    exit;
}

$idEmpresa = $stmt->insert_id;
$stmt->close();

// ===== INSERT USUARIO =====
// Campos: usuario, contrasena, nombre, apellido, estado, idRol, fechaCreacion, idUsuarioCreador, correo, cambioContrasena, legajo, idEmpresa
$sqlUsuario = "INSERT INTO usuarios 
  (usuario, contrasena, nombre, apellido, estado, idRol, fechaCreacion, idUsuarioCreador, correo, cambioContrasena, legajo, idEmpresa)
  VALUES (?, ?, ?, ?, 1, 1, NOW(), 0, ?, 1, 0, ?)";

$usuarioLogin = $correoUser;

$stmt2 = $link->prepare($sqlUsuario);
if (!$stmt2) {
    echo json_encode(["status" => "error", "message" => "Error al preparar usuario: " . $link->error]);
    exit;
}

// Tipos: s(usuario), s(contrasena), s(nombre), s(apellido), s(correo), i(idEmpresa)
$stmt2->bind_param(
    "sssssi",
    $usuarioLogin,
    $passHash,
    $nombre,
    $apellido,
    $correoUser,
    $idEmpresa
);

if (!$stmt2->execute()) {
    echo json_encode(["status" => "error", "message" => "Error al insertar usuario: " . $stmt2->error]);
    $stmt2->close();
    exit;
}

$idUsuario = $stmt2->insert_id;
$stmt2->close();

// ===== ACTUALIZAR EMPRESA para asignar responsable =====
$updateSql = $link->prepare("UPDATE empresas SET idUsuarioResponsable = ? WHERE id = ?");
if ($updateSql) {
    $updateSql->bind_param("ii", $idUsuario, $idEmpresa);
    $updateSql->execute();
    $updateSql->close();
}

// ===== CREAR SESIÓN (opcionalmente puedes dejar iniciar sesión por login real) =====
$_SESSION['idUsuario'] = $idUsuario;
$_SESSION['usuario']   = $usuarioLogin;
$_SESSION['idEmpresa'] = $idEmpresa;
$_SESSION['nombre']    = $nombre . " " . $apellido;

// ===== RESPUESTA JSON ÉXITO =====
echo json_encode([
    "status" => "success",
    "message" => "Registro exitoso",
    "data" => [
        "idUsuario" => (int)$idUsuario,
        "idEmpresa" => (int)$idEmpresa,
        "usuario"   => $usuarioLogin,
        "password_temporal" => $passPlano
    ]
]);

exit;
