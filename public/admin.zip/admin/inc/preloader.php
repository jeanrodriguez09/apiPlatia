    <!-- loader Start -->
    <div id="loading">
          <div id="loading-center">
          </div>
    </div>